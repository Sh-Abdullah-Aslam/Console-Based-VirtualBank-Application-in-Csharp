﻿using System;

namespace VP_Lab_2
{
    class Program
    {
        static void Main(string[] args)
        {
            InputOutputHandler IO_Handler = new InputOutputHandler();
            IO_Handler.printInterfaceOnTheBasisOfUser();
        }
    }   // End of class
}   // End of namespace
